"""Drive the REAL UI through the Phase 1 flow, taking a screenshot at every step.

Starts the fixture site, runner, API and the Vite dev server (via the smoke harness), then uses
a browser like a tester would. Screenshots (and optionally a video) go to the output folder.

Usage:
    uv run poe ui-walkthrough                    # screenshots to ./walkthrough/
    uv run poe ui-walkthrough --headed           # runner browser visible too
    xvfb-run -a -s "-screen 0 1440x900x24" uv run poe ui-walkthrough --record demo.webm
        # screen recording of the whole display: GATP UI + the runner's visible browser
"""

from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

import httpx
from e2e_smoke import ROOT, Smoke, free_port
from playwright.sync_api import Locator, Page, expect, sync_playwright


class Walkthrough(Smoke):
    def __init__(
        self, headed: bool, out: Path, record: Path | None, phase1_only: bool = False
    ) -> None:
        super().__init__(headed=headed or record is not None, keep=False)
        self.out = out
        self.phase1_only = phase1_only
        self.record = record
        self.web_port = free_port()
        self.web = f"http://127.0.0.1:{self.web_port}"
        self.shots: list[str] = []

    def up(self) -> None:
        super().up()
        env = {**self.env, "GATP_API_URL": str(self.api.base_url).rstrip("/")}
        log = (self.tmp / "web.log").open("wb")
        self.procs.append(
            subprocess.Popen(
                [
                    "npm",
                    "--prefix",
                    "frontend",
                    "run",
                    "dev",
                    "--",
                    "--port",
                    str(self.web_port),
                    "--host",
                    "127.0.0.1",
                ],
                cwd=ROOT,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
            )
        )
        self.wait_for("vite", lambda: httpx.get(self.web).status_code == 200, timeout=60)

    def shot(self, page: Page, name: str, element: Locator | None = None) -> None:
        path = self.out / f"{len(self.shots) + 1:02d}-{name}.png"
        if element is not None:
            element.screenshot(path=path)
        else:
            page.screenshot(path=path, full_page=True)
        self.shots.append(path.name)

    def walk(self, page: Page) -> None:
        site = self.site
        page.goto(self.web)
        expect(page.get_by_role("heading", name="Projects")).to_be_visible()
        expect(page.get_by_test_id("api-health")).to_contain_text("API ok")  # SG-001 'Verify'
        page.get_by_label("Project name").fill("BookShelf demo")
        page.get_by_label("Start URL").fill(f"{site}/index.html")
        self.shot(page, "projects-new")
        page.get_by_role("button", name="Create").click()
        expect(page.get_by_role("heading", name="Inspect pages")).to_be_visible()
        expect(page.get_by_test_id("runner-health")).to_have_text(
            "Runner ready" + ("" if self.env["GATP_RUNNER_HEADLESS"] == "false" else " (headless)")
        )
        page.get_by_test_id("tester-name").fill("Abdo")

        page.get_by_test_id("inspect-button").click()
        expect(page.get_by_test_id("findings")).to_be_visible(timeout=60_000)
        expect(page.get_by_test_id("row-e3")).to_contain_text("Sign in")
        page.get_by_test_id("row-e3").click()
        expect(page.get_by_test_id("candidates-e3")).to_contain_text("usable")
        self.shot(page, "inspect-signin-selected")
        page.get_by_test_id("row-e3").get_by_text("line 23").click()
        expect(page.get_by_test_id("source-line")).to_contain_text("login-submit")
        self.shot(page, "source-line")
        page.keyboard.press("Escape")

        page.get_by_label("Add a page of this site").fill(f"{site}/add.html")
        page.get_by_role("button", name="Add page").click()
        expect(page.get_by_role("tab", name="/add.html")).to_have_attribute("aria-selected", "true")
        panel = page.get_by_role("tabpanel")
        panel.get_by_text("setup step(s)").click()
        editor = panel.get_by_test_id("setup-editor")
        steps = [
            ("goto", None, f"{site}/index.html", None),
            ("fill", "label", "Username", "tester"),
            ("fill", "label", "Password", "secret123"),
            ("click", "test_id", "login-submit", None),
        ]
        for i, (action, strategy, target, value) in enumerate(steps, start=1):
            editor.get_by_role("button", name="Add step").click()
            editor.get_by_label(f"Step {i} action", exact=True).click()
            page.get_by_role("option", name=action, exact=True).click()
            if action == "goto":
                editor.get_by_label(f"Step {i} URL").fill(target)
                continue
            if strategy != "label":  # label is the default strategy
                editor.get_by_label(f"Step {i} locator strategy", exact=True).click()
                page.get_by_role("option", name=strategy, exact=True).click()
            editor.get_by_label(f"Step {i} locator value").fill(target)
            if value is not None:
                editor.get_by_label(f"Step {i} value", exact=True).fill(value)
        self.shot(page, "setup-steps")
        editor.get_by_role("button", name="Save steps").click()
        expect(panel.get_by_text("4 setup step(s)")).to_be_visible()
        panel.get_by_test_id("inspect-button").click()
        expect(panel.get_by_test_id("findings")).to_contain_text("Year published", timeout=60_000)
        expect(panel.get_by_test_id("row-e4")).to_contain_text("no visible label")
        panel.get_by_test_id("box-e6").click()
        expect(panel.get_by_test_id("row-e6")).to_contain_text("Save")
        self.shot(page, "inspect-add-book")

        page.get_by_test_id("step-scope").click()
        expect(page.get_by_role("heading", name="Scope and goal")).to_be_visible()
        page.get_by_test_id("goal").fill("Adding a book validates title, author, year and genre")
        add_card = page.locator(".mantine-Card-root").filter(has_text="BookShelf · Add book")
        add_card.get_by_label("e1 link “Back to books”").uncheck()
        add_card.get_by_label("e7 link “Cancel”").uncheck()
        signin_card = page.locator(".mantine-Card-root").filter(has_text="BookShelf · Sign in")
        for key in ("e1", "e2", "e3"):
            signin_card.locator(f"[data-testid$='-{key}']").uncheck()
        page.get_by_test_id("save-scope").click()
        expect(page.get_by_test_id("scope-version")).to_have_text("version 1")
        expect(page.get_by_test_id("step-scope")).to_contain_text("needs approval")
        self.shot(page, "scope-saved")
        page.get_by_test_id("approve-g0").click()
        expect(page.get_by_test_id("scope-approved")).to_be_visible()
        expect(page.get_by_test_id("step-scope")).to_contain_text("done")
        self.shot(page, "scope-approved")

        page.get_by_test_id("ask-model").click()
        expect(page.get_by_test_id("insight-summary")).to_be_visible(timeout=120_000)
        expect(page.get_by_test_id("usage")).to_contain_text("Model time")
        expect(page.get_by_test_id("browser-time")).not_to_have_text("0 ms")
        page.get_by_text("Exactly what was sent").click()
        expect(page.get_by_test_id("insight-panel")).to_contain_text("untrusted_page_data")
        self.shot(page, "model-insight", page.get_by_test_id("insight-panel"))

        if not self.phase1_only:
            self.plan_steps(page)

        page.get_by_test_id("step-scope").click()
        page.get_by_test_id("ask-model").click()  # identical request -> served from the cache
        expect(page.get_by_test_id("usage")).to_contain_text("reused")
        pid = page.url.split("/projects/")[1].split("/")[0]
        calls = self.api.get(f"/api/projects/{pid}/llm-calls").json()
        snaps = [
            {"title": s["title"], "url": s["url"], "browser_ms": s["meta"].get("browser_ms")}
            for p in self.api.get(f"/api/projects/{pid}/pages").json()
            for s in [
                self.api.get(
                    f"/api/snapshots/{self.api.get(f'/api/pages/{p["id"]}/snapshots').json()[0]['id']}"
                ).json()
            ]
        ]
        evidence = {"inspections": snaps, "llm_calls": calls}
        (self.out / "usage-evidence.json").write_text(
            json.dumps(evidence, indent=2, ensure_ascii=False) + "\n"
        )

    def plan_steps(self, page: Page) -> None:
        """T-012: propose -> clarifications -> G1 -> edit invalidates approval."""
        page.get_by_test_id("step-plan").click()
        expect(page.get_by_role("heading", name="Test plan")).to_be_visible()
        page.get_by_test_id("propose-plan").click()
        expect(page.get_by_test_id("plan-version")).to_contain_text("version 1", timeout=120_000)
        expect(page.get_by_test_id("plan-blockers")).to_contain_text("unconfirmed assumption")
        expect(page.get_by_test_id("step-plan")).to_contain_text("blocked")
        self.shot(page, "plan-proposed")
        # Answer every open clarification in the banner (assumptions: Confirm; questions: text).
        for _ in range(10):
            banner = page.get_by_text("Clarification needed (plan)").first
            if not banner.is_visible():
                break
            alert = (
                page.locator(".mantine-Alert-root")
                .filter(has_text="Clarification needed (plan)")
                .first
            )
            confirm = alert.get_by_role("button", name="Confirm")
            if confirm.count():
                confirm.click()
            else:
                alert.get_by_placeholder("Your answer").fill("Letters and digits only")
                alert.get_by_role("button", name="Answer").click()
            page.wait_for_timeout(500)
        expect(page.get_by_test_id("approve-g1")).to_be_enabled(timeout=10_000)
        page.get_by_test_id("approve-g1").click()
        expect(page.get_by_test_id("plan-approved")).to_be_visible()
        expect(page.get_by_test_id("step-plan")).to_contain_text("done")
        self.shot(page, "plan-approved")
        page.get_by_label("TC-01 title").fill("Add-book form: example input is processed")
        page.get_by_label("Edit reason").fill("clearer title")
        page.get_by_test_id("save-plan").click()
        expect(page.get_by_test_id("plan-version")).to_contain_text("version 4 · user")
        expect(page.get_by_test_id("approve-g1")).to_be_visible()  # edit -> re-approval needed
        expect(page.get_by_test_id("step-plan")).to_contain_text("needs approval")
        self.shot(page, "plan-edited-needs-reapproval")
        page.get_by_test_id("approve-g1").click()
        expect(page.get_by_test_id("plan-approved")).to_be_visible()
        self.code_steps(page)

    def code_steps(self, page: Page) -> None:
        """T-013: generate -> validate -> G2 -> injected locator caught."""
        page.get_by_test_id("step-code").click()
        expect(page.get_by_role("heading", name="Code review")).to_be_visible()
        page.get_by_test_id("generate-code").click()
        expect(page.get_by_role("tab", name="tests/test_plan.py")).to_be_visible(timeout=30_000)
        page.get_by_test_id("validate-code").click()
        expect(page.get_by_test_id("validation-status")).to_have_text(
            "validation passed", timeout=120_000
        )
        self.shot(page, "code-validated")
        page.get_by_test_id("approve-g2").click()
        expect(page.get_by_test_id("code-approved")).to_be_visible()
        expect(page.get_by_test_id("step-code")).to_contain_text("done")
        # Reviewer edit that invents a locator: must be caught and must reopen G2.
        page.get_by_role("tab", name="pages/add_page.py").click()
        editor = page.get_by_label("Code of pages/add_page.py")
        editor.fill(
            editor.input_value().replace(
                'page.locator("#title-error")', 'page.locator("#made-up")', 1
            )
        )
        page.get_by_label("Reason for editing pages/add_page.py").fill("try another selector")
        page.get_by_role("button", name="Save edit (new version, re-validate)").click()
        expect(page.get_by_test_id("approve-g2")).to_be_visible()
        page.get_by_test_id("validate-code").click()
        expect(page.get_by_test_id("validation-status")).to_have_text(
            "validation failed", timeout=120_000
        )
        expect(page.get_by_test_id("findings-list")).to_contain_text("#made-up")
        expect(page.get_by_test_id("approve-g2")).to_be_disabled()
        self.shot(page, "code-invented-locator-caught")
        # Revert the bad edit (another new version), re-validate, re-approve G2.
        editor = page.get_by_label("Code of pages/add_page.py")
        editor.fill(
            editor.input_value().replace(
                'page.locator("#made-up")', 'page.locator("#title-error")', 1
            )
        )
        page.get_by_label("Reason for editing pages/add_page.py").fill(
            "revert to the verified locator"
        )
        page.get_by_role("button", name="Save edit (new version, re-validate)").click()
        page.get_by_test_id("validate-code").click()
        expect(page.get_by_test_id("validation-status")).to_have_text(
            "validation passed", timeout=120_000
        )
        page.get_by_test_id("approve-g2").click()
        expect(page.get_by_test_id("code-approved")).to_be_visible()
        self.run_steps(page)

    def run_steps(self, page: Page) -> None:
        """T-014: G3 screen -> approve and run -> results with real failures visible."""
        page.get_by_test_id("step-run").click()
        expect(page.get_by_test_id("run-subject")).to_contain_text("You are approving (G3)")
        self.shot(page, "run-g3-subject")
        page.get_by_test_id("approve-run").click()
        status = page.get_by_test_id("run-status").first
        expect(status).to_have_text(re.compile("passed|failed"), timeout=180_000)
        self.shot(page, "run-results")
        self.feedback_steps(page)

    def feedback_steps(self, page: Page) -> None:
        """T-015: feedback on the failures -> revision -> weakening flagged -> G1/G2/G3 rerun."""
        expect(page.get_by_test_id("run-status").first).to_have_text("failed")
        page.get_by_test_id("run-feedback").fill(
            "The error regions stay empty for example input; the page shows other errors."
        )
        self.shot(page, "run-feedback")
        page.get_by_test_id("revise-from-run").click()
        expect(page.get_by_role("heading", name="Test plan")).to_be_visible()
        expect(page.get_by_test_id("plan-version")).to_contain_text("model", timeout=120_000)
        flagged = page.get_by_test_id("clarification-weakening")
        expect(flagged.first).to_contain_text("was removed")
        expect(page.get_by_test_id("approve-g1")).to_be_disabled()
        expect(page.get_by_test_id("plan-notes")).to_contain_text("removed failing check")
        self.shot(page, "plan-weakening-flagged")
        for _ in range(10):
            if not flagged.count():
                break
            flagged.first.get_by_role("button", name="Accept this change").click()
            page.wait_for_timeout(500)
        expect(page.get_by_test_id("approve-g1")).to_be_enabled(timeout=10_000)
        page.get_by_test_id("approve-g1").click()
        expect(page.get_by_test_id("plan-approved")).to_be_visible()
        page.get_by_test_id("step-code").click()
        page.get_by_test_id("generate-code").click()
        expect(page.get_by_test_id("approve-g2")).to_be_visible(timeout=30_000)
        page.get_by_test_id("validate-code").click()
        expect(page.get_by_test_id("validation-status")).to_have_text(
            "validation passed", timeout=120_000
        )
        page.get_by_test_id("approve-g2").click()
        expect(page.get_by_test_id("code-approved")).to_be_visible()
        page.get_by_test_id("step-run").click()
        page.get_by_test_id("approve-run").click()
        expect(page.get_by_test_id("run-status").first).to_have_text("passed", timeout=180_000)
        expect(page.get_by_test_id("step-run")).to_contain_text("done")
        self.shot(page, "rerun-passed")
        self.maintain_steps(page)

    def maintain_steps(self, page: Page) -> None:
        """T-016: the site changes (v1 -> v2) -> rescan -> clear match + ambiguous flagged."""
        self.switch_site("v2")
        page.get_by_test_id("step-maintain").click()
        expect(page.get_by_role("heading", name="Maintain")).to_be_visible()
        page.get_by_test_id("rescan").click()
        expect(page.get_by_test_id("rescan-status")).to_contain_text(
            "used element(s) changed", timeout=180_000
        )
        expect(page.get_by_test_id("setup-alert")).to_contain_text("read-only")
        expect(page.get_by_text("changed: clear match").first).to_be_visible()
        expect(page.get_by_text("ambiguous: you decide").first).to_be_visible()
        expect(page.get_by_test_id("step-maintain")).to_contain_text("needs approval")
        self.shot(page, "rescan-flags")

    def start_recording(self) -> subprocess.Popen[bytes] | None:
        """Record the whole X display (GATP UI + the runner's visible browser) with ffmpeg."""
        if not self.record:
            return None
        display = os.environ.get("DISPLAY")
        if not display:
            raise RuntimeError(
                "--record needs a display; run under: xvfb-run -a -s '-screen 0 1440x900x24'"
            )
        self.record.parent.mkdir(parents=True, exist_ok=True)
        return subprocess.Popen(
            [
                "ffmpeg",
                "-y",
                "-loglevel",
                "error",
                "-video_size",
                "1440x900",
                "-framerate",
                "15",
                "-f",
                "x11grab",
                "-i",
                display,
                "-c:v",
                "libvpx-vp9",
                "-b:v",
                "600k",
                "-deadline",
                "realtime",
                "-cpu-used",
                "8",
                str(self.record),
            ],
            stdin=subprocess.PIPE,
        )

    def stop_recording(self, recorder: subprocess.Popen[bytes] | None) -> None:
        if recorder is None or recorder.stdin is None:
            return
        recorder.stdin.write(b"q")
        recorder.stdin.flush()
        recorder.wait(timeout=60)
        size = self.record.stat().st_size // 1024 if self.record else 0
        print(f"recorded {self.record} ({size} kB)")

    def run_ui(self) -> int:
        self.out.mkdir(parents=True, exist_ok=True)
        for old in self.out.glob("*.png"):
            old.unlink()
        executable = os.environ.get("GATP_CHROMIUM_EXECUTABLE") or None
        recorder = self.start_recording()
        with sync_playwright() as pw:
            if self.record:
                # Visible, slowed-down browser so the screen recording is watchable.
                browser = pw.chromium.launch(
                    executable_path=executable,
                    headless=False,
                    slow_mo=250,
                    args=["--window-position=0,0", "--window-size=1440,900"],
                )
                context = browser.new_context(no_viewport=True)
            else:
                browser = pw.chromium.launch(executable_path=executable)
                context = browser.new_context(viewport={"width": 1440, "height": 900})
            page = context.new_page()
            errors: list[str] = []
            page.on("pageerror", lambda exc: errors.append(f"page error: {exc}"))
            page.on(
                "console",
                lambda m: (
                    errors.append(f"console.{m.type}: {m.text}") if m.type == "error" else None
                ),
            )
            started = time.perf_counter()
            try:
                self.walk(page)
                status = 0
            except Exception as exc:
                self.shot(page, "FAILED")
                print(f"FAIL  {type(exc).__name__}: {exc}")
                status = 1
            if self.record:
                page.wait_for_timeout(2000)  # hold the last screen for a moment
            context.close()
            browser.close()
        self.stop_recording(recorder)
        for e in errors:
            print(f"  {e[:400]}")
            status = 1 if e.startswith("page error") else status
        print(
            f"{'OK' if status == 0 else 'FAILED'} in {time.perf_counter() - started:.1f}s; screenshots in {self.out}:"
        )
        for s in self.shots:
            print(f"  {s}")
        return status


def main() -> int:
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter
    )
    parser.add_argument("--headed", action="store_true")
    parser.add_argument("--record", type=Path, help="screen-record to this .webm (needs a display)")
    parser.add_argument("--out", type=Path, default=Path("walkthrough"))
    parser.add_argument(
        "--phase1-only",
        action="store_true",
        help="stop after the grounded model call + cache check and export usage evidence",
    )
    args = parser.parse_args()
    w = Walkthrough(
        args.headed,
        args.out.resolve(),
        args.record.resolve() if args.record else None,
        args.phase1_only,
    )
    try:
        w.up()
        return w.run_ui()
    except RuntimeError as exc:
        print(f"FAIL  startup: {exc}")
        w.failures += 1
        return 1
    finally:
        w.down()


if __name__ == "__main__":
    sys.path.insert(0, str(Path(__file__).parent))
    raise SystemExit(main())
