# Module: runner

- **Owner:** TBD
- **Status:** Implemented (transport, inspect, recount; T-006; approved runs under bubblewrap, T-014)
- **Code:** `backend/src/gatp/runner/` (separate entrypoint, separate process)
- **Tasks:** T-006, T-014
- **ADRs:** ADR-004, ADR-008, ADR-012, ADR-017

## Responsibility
A restricted, separately started process that executes only typed jobs from the api: `inspect` (opens a visible browser, calls inspector) and `run_tests` (executes approved, validated test code). Enforces the target allowlist and a fresh sandbox working directory per job. No shell access, no arbitrary commands.

## Interfaces
| Direction | Interface | Contract |
|---|---|---|
| Provides | HTTP on a Unix socket (`GATP_RUNNER_SOCKET`, 0600) | `GET /health`; `POST /jobs` with `{"job": Job}` → `JobResult`; 422 if the job is invalid |
| Provides | `RunnerClient` (`runner/client.py`) | Used by the api only (import contracts) |
| Consumes | inspector | `LocatorSpec` + `resolve()` (T-006), extraction (T-007) |

## Job contract
| Job (`type`) | Input | Output (`JobResult.data` / `files`) | Since |
|---|---|---|---|
| `inspect` | `url`, `allowlist`, `timeout_s` | `title`, `final_url` / `screenshot` (full extraction in T-007) | T-006 |
| `recount` | `url`, `allowlist`, `locators: [LocatorSpec]`, optional `setup` steps | `counts: [int]` (same order) | T-006 (setup: T-013) |
| `collect` | `files` {path: content} (paths limited to `pages/*.py`, `tests/test_*.py`, `conftest.py`) | `tests` (ids), `exit_code`, `output` | T-013 |
| `run_tests` | approved `files`, `base_url`, `allowlist`, `tests` (empty = all), `timeout_s` | `results[]` (test_id, outcome, duration_ms, message, details, screenshots), `isolation`, `exit_code`, `blocked_requests`; files: junit XML, screenshots | T-014 |

Every `JobResult` has `job_id`, `type`, `status` (`ok`/`failed`), `duration_ms` (browser/test time, separate from model time), `blocked_requests`, `files` (artifact-relative paths), `data` and `error`.

## Files
| File | Contents |
|---|---|
| `jobs.py` | Pydantic job models (discriminated union, `extra="forbid"`, URL-in-allowlist validator), `JobResult`, `BlockedRequest` |
| `executor.py` | `JobExecutor`: one worker thread, sandbox per job, runs `inspect` / `recount` |
| `browser.py` | `open_page()` (headed unless configured otherwise, service workers blocked), `Allowlist` route handler |
| `sandbox.py` | `job_sandbox()` → `data/sandbox/job-<id>/` (0700, deleted afterwards); `Sandbox.keep()` copies outputs to `artifacts/jobs/<id>/` |
| `server.py` | FastAPI app (`/health`, `/jobs`) |
| `main.py` | `gatp-runner`: binds the 0600 socket in a 0700 dir, runs uvicorn on it |
| `client.py` | `RunnerClient`, `RunnerUnavailableError`, `RunnerRejectedError` |

## Approved test runs (T-014, [ADR-022](../../decisions/ADR-022-approved-execution-sandbox.md))
`execute.py` writes the files, `gatp_run_plugin.py` and its own `pytest.ini` into the job sandbox, then runs `python -m pytest -p gatp_run_plugin --junitxml=… --screenshot=on` inside **bubblewrap**: read-only `/`; GATP data/artifacts/.env and ~/.ssh, ~/.config, … hidden; only the sandbox writable; new PID/IPC/UTS namespaces; cleared environment. The plugin adds origin-allowlist routing to every test browser context and records blocked requests. Results come from junit XML; screenshots are matched per test and copied to `artifacts/jobs/<id>/`. `GATP_RUNNER_ISOLATION=process` is a weaker fallback.

## Restrictions (enforced)
- **Jobs:** typed only, no shell or code endpoint. An unknown job type or extra field gets HTTP 422.
- **Target:** the URL must be on an allowlisted origin, or the job is rejected before running.
- **Network:** requests to other origins are aborted (`blockedbyclient`) and listed in `blocked_requests`.
- **Files:** a fresh 0700 sandbox per job, removed afterwards; only explicitly kept files reach `artifacts/`.
- **Access:** the socket is 0600 in a 0700 directory, and there's no TCP port.
- **Timeouts:** per job (`timeout_s`), applied as Playwright's default timeout. Defaults and caps differ by job type: inspect 30 s (max 600 s), collect 60 s (max 300 s), run_tests 300 s (max 1800 s); see `runner/jobs.py`.
- **Browser:** headed Chromium. `GATP_RUNNER_HEADLESS=true` only in CI. `GATP_RUNNER_SLOW_MO_MS` slows actions down for demos.

## Config
| Key | Default | Meaning |
|---|---|---|
| `GATP_RUNNER_SOCKET` | `data/runner/runner.sock` | Unix socket path |
| `GATP_RUNNER_HEADLESS` | `false` | CI only |
| `GATP_RUNNER_SANDBOX_DIR` | `data/sandbox` | Per-job sandboxes |
| `GATP_RUNNER_JOB_TIMEOUT_S` | `60` | Default job timeout used by the api |
| `GATP_RUNNER_SLOW_MO_MS` | `0` | Slow motion for demos |
| `GATP_CHROMIUM_EXECUTABLE` | empty | Use a specific Chromium binary |

## Tests
`test_runner_jobs.py`, `test_runner_browser.py`, `test_runner_process.py` (TC-106).

## Known limitations
- Process isolation, not a container. The runner shares the OS user with the api; test-code confinement is bubblewrap, the default for `run_tests` since T-014 (T-020 is hardening only).
- One job at a time (by design: one visible browser).
