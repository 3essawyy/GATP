# GATP: Human-in-the-Loop Web Testing Assistant

Course project, *Generative AI for Software Testing* (Fall 2026).

GATP inspects a web page in a visible, isolated browser, lets a human choose a testing goal and the elements in scope, and uses a model to summarise the selection and suggest next actions grounded in what was actually observed. A human approves each consequential step.

## Stack

| Part | Technology |
|---|---|
| Backend | Python 3.12, FastAPI, SQLite (SQLAlchemy + Alembic), `uv` |
| Frontend | React + Vite + TypeScript, Mantine, TanStack Query |
| Browser runner | Separate process (Playwright for Python, visible Chromium), reached over a private Unix socket |
| Model | Google Gemini (free tier) primary; Ollama local fallback; `fake` provider for offline use |

## Requirements

- **Linux** (Ubuntu 24.04). On Windows use **WSL2**; the browser window shows through WSLg.
- [`uv`](https://docs.astral.sh/uv/) and **Node.js 22+**
- Chromium for Playwright (step 3), and `bubblewrap` if you use the default test-run isolation (`sudo apt install bubblewrap`)

## Setup

```bash
# 1. Python dependencies (creates .venv)
uv sync

# 2. Frontend dependencies
uv run poe web-install

# 3. Chromium + system libraries for the runner (asks for sudo)
uv run poe browsers

# 4. Configuration (see "Model configuration")
cp .env.example .env        # then add your Gemini key
```

## Model configuration

All settings live in `.env` (copy of `.env.example`, never committed). The ones that matter:

| Variable | Default | Meaning |
|---|---|---|
| `GATP_LLM_PRIMARY` | `gemini` | `gemini`, `ollama` or `fake` (deterministic, offline, labelled as fake in the UI) |
| `GATP_GEMINI_API_KEY` | empty | Free-tier key from https://aistudio.google.com/apikey |
| `GATP_GEMINI_MODEL` | `gemini-3.5-flash-lite` | Model used for the grounded call |
| `GATP_LLM_FALLBACK` | `ollama` | Used if the primary fails |
| `GATP_OLLAMA_HOST` / `GATP_OLLAMA_MODEL` | `http://127.0.0.1:11434` / `qwen2.5-coder:3b` | Local fallback model |
| `GATP_LLM_TIMEOUT_S` | `120` | Per-call timeout (free-tier calls can take 5 to 70 s) |

Only free or local models are used. Check your setup with a tiny logged call:

```bash
uv run poe llm-check
```

Every model call is logged (provider, model, version, tokens and whether they were reported or estimated, model latency, fresh or reused, exact request) and shown on the usage card in the UI.

## Run

Start each in its own terminal, from the repository root:

```bash
uv run poe fixtures v1   # BookShelf test site     http://127.0.0.1:8090
uv run poe runner        # isolated browser runner
uv run poe api           # FastAPI backend         http://127.0.0.1:8000
uv run poe web           # UI                      http://localhost:5173
```

Open http://localhost:5173. Both header badges ("Runner ready", "API ok") should be green.

## Try it

1. **Projects** → name `BookShelf demo`, start URL `http://127.0.0.1:8090/index.html` → **Create**.
2. Enter your name in the header (recorded with every approval).
3. **Inspect /index.html**. A Chromium window opens in the runner, extracts the interactive elements and their live-verified locators, and closes.
4. Add the page `http://127.0.0.1:8090/add.html`. Under **Before inspecting** add four setup steps (a protected page is reached through tester-approved steps):
   `goto` `http://127.0.0.1:8090/index.html` (full URL) · `fill` label `Username` = `tester` · `fill` label `Password` = `secret123` · `click` test_id `login-submit`. Save steps, then inspect `/add.html`.
5. **Scope & goal**: enter a goal, untick elements you don't want, **Save scope**, then **Approve scope (G0)**.
6. **Summarise & suggest next actions**: one model call on the in-scope elements only. Run it twice: the second is reused from the cache.

A sample of the structured inspection output is delivered alongside this package.

## Checks

```bash
uv run poe check           # lint, mypy --strict, pytest, frontend lint/typecheck/build
uv run poe check-backend   # backend only
```

## Layout

```
pyproject.toml      Python project, tool config and `poe` tasks
backend/src/gatp/   FastAPI app, runner, inspector, LLM gateway, store (one sub-package per module)
backend/tests/      pytest suite
frontend/           React/Vite/TS UI (API client generated from OpenAPI)
fixtures/           BookShelf test website: site-v1 (baseline), site-v2 (modified), serve.py
```

## Limitations

- Linux/WSL2 only; the runner needs a display (WSLg or Xvfb) because the browser is visible.
- Free-tier Gemini latency varies (about 5 to 70 s per call) and it can return transient 503s.
- Webpage content is treated as data, never as instructions.
