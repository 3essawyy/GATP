"""API: FastAPI JSON API, workflow state, approval gates."""
