"""Test designer: grounded test case proposals and clarifications."""
