"""LLM gateway: the only module that talks to model providers.

Public API: ``LLMGateway.complete_structured`` (+ ``LLMResult``, ``LLMOutputError``,
``LLMUnavailableError``), ``PromptTemplate`` / ``registry`` for feature prompts.
"""
