"""Store: SQLite schema, immutable versioning, artifacts.

Public API: ``Database``, the repositories (``ProjectRepository``, ``SnapshotRepository``,
``ArtifactStore``), ``ArtifactFiles`` and the DTOs in ``gatp.store.dto``.
"""
